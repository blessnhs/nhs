#include "StdAfx.h"
#include "BCRoom.h"


BCRoom::BCRoom(void)
{
}


BCRoom::~BCRoom(void)
{
}
