#include "StdAfx.h"
#include "Group.h"
#include "../Process/Sender.h"
#include "../IOCP/TCP/ServerIOCP_TCP.h"

namespace GSRelayServer	{	namespace Group	{


Group::Group(void)
{
}

Group::~Group(void)
{
}

VOID Group::BroadCastUDP(char *Message)
{

}


}	}