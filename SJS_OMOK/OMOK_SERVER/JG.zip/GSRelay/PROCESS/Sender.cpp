#include "StdAfx.h"

#include "Sender.h"
