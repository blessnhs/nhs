#pragma once

#pragma pack( push ,1 )


////////////////////////////////////////////////////////////////////////////
enum _PROTOCOL_DBA
{
	// ���������� ������ �˸��ϴ�.
	PT_VERSION_DBA	= 1,

	DBP_GET_LOGIN_INFO,
	DBP_GET_LOGIN_INFO_RE,
	DBP_GET_CHAR_INFO,
	DBP_GET_CHAR_INFO_RE,

	DBP_UPDATE_CHAR_INFO,
	DBP_UPDATE_CHAR_INFO_RE,

	DBP_REQUEST_CHANNEL_LIST,
	DBP_REQUEST_CHANNEL_LIST_RE,

	DBP_REQUEST_CLOSE_PLAYER,
	DBP_REQUEST_CLEAR_CONCURRENT,
};

////////////////////////////////////////////////////////////////////////////

#pragma pack()
