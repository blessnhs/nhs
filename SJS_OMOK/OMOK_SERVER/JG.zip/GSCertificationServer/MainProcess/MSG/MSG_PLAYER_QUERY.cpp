#include "StdAfx.h"
#include "MSG_PLAYER_QUERY.h"

namespace Certification	{
	
}

