#include "StdAfx.h"
#include "MSG_PLAYER_QUERY_RES.h"

#include "ICommand.h"
#include "GSPacketTCP.h"
#include "IProcess.h"


#include "../../db/DBProxy/DBProcess.h"

namespace Certification	{

}