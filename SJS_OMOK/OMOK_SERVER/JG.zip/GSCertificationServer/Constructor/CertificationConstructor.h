#pragma once
class CertificationConstructor
{
public:
	CertificationConstructor(void);
	~CertificationConstructor(void);
};

