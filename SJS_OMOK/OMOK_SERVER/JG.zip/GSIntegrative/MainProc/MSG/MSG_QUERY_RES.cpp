#include "stdafx.h"
#include "MSG_QUERY_RES.h"
