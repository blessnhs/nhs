#include "StdAfx.h"
#include "Log.h"


Log::Log(LPCTSTR file_name)
	:GSLog(file_name)
{
}


Log::~Log(void)
{
}
