#pragma once

class GSConstructor
{
public:
	GSConstructor(void);
	~GSConstructor(void);
};

