#pragma once

#include "GSMainProcess.h"

namespace GSFrontServer	{	namespace GSConstructor	{

class GSConstructor
{
public:
	GSConstructor(void);
	~GSConstructor(void);

private:

};

}	}
