#pragma once

#include "ICommand.h"
#include "IMessage.h"

namespace GSFrontServer	{

template<class T>
class MSG_PLAYER_QUERY_RES;

}

#include "MSG_PLAYER_QUERY_RES.hpp"