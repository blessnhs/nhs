#include "StdAfx.h"
#include "MSG_PLAYER_QUERY_RES.h"

#include "ICommand.h"
#include "GSPacketTCP.h"
#include "IProcess.h"

#include "../../PLAYER/Container/Player.h"
#include "../../DBProxy/DBProcess.h"
#include "../../DBProxy/DBJob/RequestPlayerAuth.h"

namespace GSFrontServer	{

}