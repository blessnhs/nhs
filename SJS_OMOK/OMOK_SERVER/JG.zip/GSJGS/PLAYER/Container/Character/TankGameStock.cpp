#include "StdAfx.h"
#include "./TankGameStock.h"


TankGameStock::TankGameStock()
{
}

TankGameStock::~TankGameStock()
{

}
