#pragma once

class TankGameStock
{
public:

	TankGameStock();
	~TankGameStock();


};