#pragma once

class ACGameStock
{
public:

	ACGameStock();
	~ACGameStock();

private:


};