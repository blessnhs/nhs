#include "StdAfx.h"
#include "./ACGameStock.h"


ACGameStock::ACGameStock()
{
}

ACGameStock::~ACGameStock()
{

}

