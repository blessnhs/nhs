#include "StdAfx.h"
#include "./IGameRule.h"


namespace GSFrontServer	{	namespace	Room	{	namespace IGameRule		{

}	}	}