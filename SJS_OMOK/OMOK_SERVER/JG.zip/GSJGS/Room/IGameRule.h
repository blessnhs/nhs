#pragma once


namespace GSFrontServer	{	namespace	Room	{	namespace IGameRule		{

	class IGameRule
	{
	public:
		IGameRule() {}
		~IGameRule() {}
	};


}	}	}