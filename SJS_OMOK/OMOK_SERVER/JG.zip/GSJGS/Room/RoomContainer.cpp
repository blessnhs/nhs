#include "StdAfx.h"
#include "RoomContainer.h"

namespace GSFrontServer	{	namespace	RoomContainer	{

/*extern RoomContainer<GSCreator> &GetRoomContainer()
{
	static RoomContainer<GSCreator> g_RoomContainer;
	return g_RoomContainer;
}*/

}	}