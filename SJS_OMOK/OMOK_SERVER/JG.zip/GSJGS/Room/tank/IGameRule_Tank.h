#pragma once

#include "../IGameRule.h"


namespace GSFrontServer	{	namespace	Room	{	namespace IGameRule		{	namespace	IGameRule_Tank    {

	class IGameRule_Tank
	{
	public:
		IGameRule_Tank() {}
		~IGameRule_Tank() {}
	};


}	}	}	}