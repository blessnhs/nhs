#include "StdAfx.h"
#include "./IGameRule_Tank.h"


namespace GSFrontServer	{	namespace	Room	{	namespace IGameRule		{	namespace	IGameRule_Tank    {

}	}	}	}