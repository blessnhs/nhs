#include "StdAfx.h"
#include "FrontLog.h"


FrontLog::FrontLog(LPCTSTR file_name)
	:GSLog(file_name)
{
}


FrontLog::~FrontLog(void)
{
}
