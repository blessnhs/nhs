#include "StdAfx.h"
#include "GSParam.h"


GSParam::GSParam(void)
{
}


GSParam::~GSParam(void)
{
}
