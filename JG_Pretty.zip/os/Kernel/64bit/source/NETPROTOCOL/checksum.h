
#ifndef _CHECKSUM_H
#define _CHECKSUM_H

extern unsigned short checksum16 (void *_buf, int len);

#endif
