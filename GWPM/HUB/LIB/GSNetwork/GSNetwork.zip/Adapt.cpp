#include "StdAfx.h"
#include "Adapt.h"
#include "IPlayerProcess.h"
#include "IServerProcess.h"

namespace GSNetwork {	namespace Adapt	{

Adapt::Adapt(void)
{
}


Adapt::~Adapt(void)
{
}

}	}
