#include "StdAfx.h"
#include "Functor.h"

