#include "StdAfx.h"
#include "GSAllocator.h"

namespace GSNetwork	{

GSAllocator::GSAllocator(void)
{
}


GSAllocator::~GSAllocator(void)
{

}

}